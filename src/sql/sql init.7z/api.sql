/*
Navicat MySQL Data Transfer

Source Server         : MYSQL
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : api

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2018-02-28 13:47:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_api
-- ----------------------------
DROP TABLE IF EXISTS `sys_api`;
CREATE TABLE `sys_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `db_id` int(10) unsigned zerofill DEFAULT '0000000001',
  `uid` int(11) DEFAULT NULL,
  `api_name` varchar(255) DEFAULT NULL,
  `nonce` varchar(255) DEFAULT NULL,
  `sqlstr` text,
  `param` varchar(255) DEFAULT NULL,
  `rec_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_api
-- ----------------------------
INSERT INTO `sys_api` VALUES ('1', '0000000001', '49', ' 接口列表', 'e61799e7ab', 'SELECT a.id, b.db_name 数据库, a.api_name 接口名称, a.nonce, a.sqlstr 查询语句, ( CASE WHEN isnull(a.param) THEN \'\' ELSE a.param END ) 查询参数, a.rec_time 建立时间, a.update_time 最近更新, a.db_id FROM sys_api a INNER JOIN sys_database b on a.db_id = b.id WHERE a.id >3 order by a.id desc', '', '2017-07-30 03:07:37', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('2', '0000000001', '49', '数据库列表', '6119bacd08', 'SELECT a.id,a.db_name text FROM sys_database AS a', '', '2017-11-24 00:49:19', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('3', '0000000001', '49', '数据库列表', 'e4e497e849', 'select id,db_name 数据库名,db_key 配置项键值 from sys_database', '', '2017-11-24 16:02:10', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('4', '0000000002', '49', '用户类型列表', 'dc2861d656', 'SELECT type_id value,type_name name FROM data_user_type a ORDER BY 1', '', '2017-11-27 00:41:18', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('5', '0000000002', '49', '部门列表', '145ce9a426', 'SELECT a.id value,a.dept_name name FROM data_dept a WHERE a.status=1 or a.id=1', '', '2017-12-07 21:22:51', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('6', '0000000002', '49', '用户列表', 'f150045a94', 'SELECT a.id,a.username,a.type_id,a.dept,(case when isnull(c.dept_name) then \'无\' else c.dept_name end) dept_name,a.status,(case when a.status =1 then \'激活\' else \'注销\' end) status_name,b.type_name FROM data_user a LEFT JOIN data_user_type b on a.type_id = b.type_id LEFT JOIN data_dept c on a.dept = c.id order by a.status desc,a.id', '', '2017-12-07 21:51:36', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('7', '0000000002', '49', '部门列表', '6f77963c65', 'SELECT a.id value ,a.dept_name name,a.status,a.uid FROM data_dept a order by a.order_idx', '', '2017-12-08 00:16:44', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('8', '0000000002', '49', '公司领导列表', '719f24df9c', 'SELECT a.id value,a.username name FROM `data_user` a where a.`status`=1 and a.type_id in (0,1)', '', '2017-12-08 00:37:22', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('9', '0000000002', '49', '公司领导分管部门', '596c278e0b', 'SELECT a.username,a.id uid,b.dept_name name,b.id value FROM `data_user` a INNER JOIN data_dept b on a.type_id in (0,1) and a.status=1 and a.id = b.uid', '', '2017-12-08 17:25:17', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('10', '0000000002', '49', '履职能力评价任务列表', '302ea10d9f', 'select * from view_task_list a ORDER BY a.end_time DESC,id DESC', '', '2017-12-08 22:01:25', '2018-01-11 11:51:33');
INSERT INTO `sys_api` VALUES ('11', '0000000002', '49', '参与评分部门列表', 'e6d832ad83', 'SELECT a.id value,a.dept_name name,b.username as leader FROM data_dept a INNER JOIN data_user b on a.uid = b.id WHERE a.status=1', '', '2017-12-09 00:15:54', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('12', '0000000002', '49', '部门领导人员列表', 'd91dabea8f', 'SELECT username,dept FROM `data_user` where type_id=2 and `status`=1', '', '2017-12-09 00:47:58', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('13', '0000000002', '49', '用户评分历史数据', 'e7bfeab257', 'SELECT a.id,b.dept_name name,a.dept_id,a.score_work,a.score_team,a.score_service,a.score_enhance,a.score_sub AS `value` FROM data_score AS a INNER JOIN data_dept AS b ON a.dept_id = b.id where a.uid=? and a.task_id=? order by a.score_sub', 'uid,task_id', '2017-12-10 21:02:26', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('14', '0000000002', '49', '用户基本信息', '78473cfd9b', 'SELECT a.id,a.type_id,dept FROM `data_user` a where uid = ? and status=1', 'uid', '2017-12-11 09:47:10', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('15', '0000000002', '49', '得分情况', '09a7b28c5d', 'SELECT a.dept_id,a.`被评价部门` dept,a.`主管领导` leader,a.leader_uid,a.`工作效果`,a.`团队建设`,a.`服务配合`,a.`持续改进`,a.`总分` score_sub,a.最高分,a.最低分,a.算术平均分,a.领导评分,a.部门互评 FROM view_score_stat AS a WHERE a.task_id =? ORDER BY a.总分', 'taskid', '2017-12-11 23:44:13', '2017-12-18 21:25:53');
INSERT INTO `sys_api` VALUES ('16', '0000000002', '49', '部门得分详情', '481b099e41', 'SELECT a.score_work,a.score_team,a.score_service,a.score_enhance,a.score_sub FROM `data_score` a where task_id=? and dept_id=? and uid<>44', 'task_id,dept_id', '2017-12-13 22:54:45', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('17', '0000000002', '49', '部门评分历史得分', 'd49f6ab566', 'select dept_id,总分 from view_score_stat where task_id=(SELECT max(task_id) FROM view_score_stat where task_id<?) order by 2 desc', 'task_id', '2017-12-18 00:11:54', '2017-12-18 00:33:27');
INSERT INTO `sys_api` VALUES ('18', '0000000001', '49', '更新密码', '63bc967cec', 'update sys_user set psw =? where id =? and psw=MD5(concat(\'wMqSakbLdy9t8LLD\',?))', 'new,uid,old', '2017-12-18 02:10:47', '2017-12-18 02:11:12');
INSERT INTO `sys_api` VALUES ('19', '0000000001', '49', '用户登录', '209a76b78d', 'select id from sys_user where id =? and psw=MD5(concat(\'wMqSakbLdy9t8LLD\',?))', 'uid,psw', '2017-12-18 02:50:11', '2017-12-18 02:50:11');
INSERT INTO `sys_api` VALUES ('20', '0000000003', '49', '20180109ASRS测试数据', '10643a2f37', 'select v.floor_nm \"楼层\",v.direction \"区域\",v.goods_code \"产品\",v.process_code \"工序\",v.batch_no \"车号\",v.task_start_time \"任务开始\",v.task_end_time \"任务结束\",(v.task_end_time-v.task_start_time)*24*60*60 \"任务持续\" from mac2.tb_wim_recpay v where v.mes_manage_num between 5696566 and 5697054 order by v.mes_manage_num;', '楼层,区域,产品,工序', '2018-01-10 09:33:46', '2018-01-10 09:35:37');
INSERT INTO `sys_api` VALUES ('21', '0000000002', '49', '评价完成情况', '8b1c3d5e59', 'select d.dept_name 部门,b.username 评价人员,count(a.id) 完成数 from data_score a INNER JOIN data_user b on a.uid = b.id INNER JOIN data_dept d on d.id = b.dept where a.task_id=? group by d.dept_name,b.username', 'task_id', '2018-01-11 11:57:06', '2018-01-11 11:57:06');

-- ----------------------------
-- Table structure for sys_database
-- ----------------------------
DROP TABLE IF EXISTS `sys_database`;
CREATE TABLE `sys_database` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `db_name` varchar(255) DEFAULT NULL,
  `db_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_database
-- ----------------------------
INSERT INTO `sys_database` VALUES ('1', '接口管理', 'db1');
INSERT INTO `sys_database` VALUES ('2', '用户数据', 'db2');
INSERT INTO `sys_database` VALUES ('3', 'wip_wms_test', 'wms_test');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `psw` varchar(255) NOT NULL,
  `rec_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', '赵平昌', '赵平昌', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-18 02:09:29', '2017-12-18 02:09:29');
INSERT INTO `sys_user` VALUES ('2', '刘科', '刘科', '2303e9cfd114fb5eb1dcc4f4d2d9b699', '2018-01-08 12:51:22', '2018-01-08 12:51:22');
INSERT INTO `sys_user` VALUES ('3', '时延风', '时延风', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('4', '肖福君', '肖福君', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('5', '黄从军', '黄从军', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('6', '周承军', '周承军', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('7', '赵兴涛', '赵兴涛', '53200163ca7da562e01db20994cf0e82', '2018-01-04 11:56:59', '2018-01-04 11:56:59');
INSERT INTO `sys_user` VALUES ('8', '谭伟', '谭伟', '11c292b26e7ca9b11ab892ef8627ea63', '2018-01-12 15:19:16', '2018-01-12 15:19:16');
INSERT INTO `sys_user` VALUES ('9', '曾丽', '曾丽', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('10', '唐璇', '唐璇', '88a020b929550b600a4804c414fd8168', '2018-01-03 10:06:50', '2018-01-03 10:06:50');
INSERT INTO `sys_user` VALUES ('11', '沈秋林', '沈秋林', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('12', '李科', '李科', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('13', '赵洪新', '赵洪新', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('14', '张楠岚', '张楠岚', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('15', '达时', '达时', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('16', '武明凯', '武明凯', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('17', '吕树荣', '吕树荣', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('18', '张宪', '张宪', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('19', '高琼', '高琼', 'b749fa2e86c735566b7538349ed1c791', '2018-01-04 11:18:14', '2018-01-04 11:18:14');
INSERT INTO `sys_user` VALUES ('20', '李向鹏', '李向鹏', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('21', '谢安山', '谢安山', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('22', '龙玉蓉', '龙玉蓉', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('23', '王波皓', '王波皓', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('24', '曾丹', '曾丹', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('25', '姜鎏', '姜鎏', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('26', '吴玉波', '吴玉波', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('27', '宋燕宁', '宋燕宁', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('28', '周培华', '周培华', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('29', '王昌明', '王昌明', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('30', '贾燕', '贾燕', 'b48b9a5b36dbf17bf37853e1a5edfbc5', '2018-01-11 11:33:49', '2018-01-11 11:33:49');
INSERT INTO `sys_user` VALUES ('31', '赵军', '赵军', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('32', '陈杰', '陈杰', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('33', '赵永康', '赵永康', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('34', '徐晓林', '徐晓林', '705922abb1f6c4ae9e89dd1499cd2e1e', '2018-01-12 13:41:17', '2018-01-12 13:41:17');
INSERT INTO `sys_user` VALUES ('35', '荀文军', '荀文军', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('36', '苟尚舜', '苟尚舜', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('37', '杨文群', '杨文群', '80f2d85f4bb7f6506d50cb8ae3a386ba', '2018-01-04 13:48:44', '2018-01-04 13:48:44');
INSERT INTO `sys_user` VALUES ('38', '刘莘', '刘莘', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('39', '颜静', '颜静', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('40', '陈玉群', '陈玉群', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('41', '黄纯', '黄纯', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('42', '权泉', '权泉', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('43', '唐晓琴', '唐晓琴', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('44', '袁玉琳', '袁玉琳', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('45', '杨帆', '杨帆', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('46', '黄莉', '黄莉', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('47', '高钟', '高钟', 'db73eac300f30207b18293b393658df3', '2018-01-10 08:23:48', '2018-01-10 08:23:48');
INSERT INTO `sys_user` VALUES ('48', '付保伍', '付保伍', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:05:20', null);
INSERT INTO `sys_user` VALUES ('49', 'develop', '管理员', '11c292b26e7ca9b11ab892ef8627ea63', '2017-12-17 16:06:51', null);
INSERT INTO `sys_user` VALUES ('50', '韩兴虎', '韩兴虎', '11c292b26e7ca9b11ab892ef8627ea63', '2018-01-02 09:21:44', null);
DROP TRIGGER IF EXISTS `api_nonce`;
DELIMITER ;;
CREATE TRIGGER `api_nonce` BEFORE INSERT ON `sys_api` FOR EACH ROW set new.nonce = substring(MD5(RAND()*100),1,10)
;
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `api_rectime`;
DELIMITER ;;
CREATE TRIGGER `api_rectime` BEFORE INSERT ON `sys_api` FOR EACH ROW SET new.rec_time = CURRENT_TIMESTAMP,new.update_time = CURRENT_TIMESTAMP
;
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `api_update`;
DELIMITER ;;
CREATE TRIGGER `api_update` BEFORE UPDATE ON `sys_api` FOR EACH ROW SET new.update_time = CURRENT_TIMESTAMP
;
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `insert`;
DELIMITER ;;
CREATE TRIGGER `insert` BEFORE INSERT ON `sys_user` FOR EACH ROW SET new.psw = MD5(concat('wMqSakbLdy9t8LLD',new.psw)),new.rec_time = CURRENT_TIMESTAMP
;
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `update`;
DELIMITER ;;
CREATE TRIGGER `update` BEFORE UPDATE ON `sys_user` FOR EACH ROW if new.psw<>old.psw then
   SET new.psw = MD5(concat('wMqSakbLdy9t8LLD',new.psw)),new.update_time = CURRENT_TIMESTAMP;
else
  SET new.update_time = CURRENT_TIMESTAMP;
end if
;;
DELIMITER ;
